package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.view.View;
import android.widget.*;

import com.google.gson.Gson;

public class CEPAsync extends AsyncTask<String, Void, String> {

    private ProgressBar pBar;
    private Button button;

    public CEPAsync(ProgressBar prog, Button btn){
        this.pBar = prog;
        this.button = btn;
    }

    @Override
    protected void onPreExecute() {
        this.pBar.setVisibility(View.VISIBLE);
        this.button.setEnabled(false);
        super.onPreExecute();
    }

    @Override
    protected String doInBackground(String... params) {
        String url = "http://viacep.com.br/ws/" + params[0] + "/json/";
        return HttpRequestor.get(url);
    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }

    @Override
    protected void onPostExecute(String s) {
        this.pBar.setVisibility(View.INVISIBLE);
        this.button.setEnabled(true);
        if (s == null){
            Toast.makeText(this.pBar.getContext(), "Retorno nulo do servidor.", Toast.LENGTH_SHORT).show();
        }
        else{
            if (s.contains("(500)") || s.contains("(400)") || s.contains("\"erro\": true")){
                Toast.makeText(this.pBar.getContext(), "Erro na requisição.", Toast.LENGTH_SHORT).show();
            }
            else{
                //sucesso
                Intent i = new Intent(pBar.getContext(),  ResultadoActivity.class);
                i.putExtra("resultado", s);
                pBar.getContext().startActivity(i);
                //Toast.makeText(this.pBar.getContext(), s, Toast.LENGTH_LONG).show();
            }
        }

        super.onPostExecute(s);
    }
}
