package com.example.myapplication;

import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ResultadoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultado);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        TextView textViewRua    = (TextView)this.findViewById(R.id.rua);
        TextView textViewCEP    = (TextView)this.findViewById(R.id.cep);
        TextView textViewBairro = (TextView)this.findViewById(R.id.bairro);
        TextView textViewCidade = (TextView)this.findViewById(R.id.cidade);
        TextView textViewEstado = (TextView)this.findViewById(R.id.estado);

        String resultado = (String)this.getIntent().getSerializableExtra("resultado");
        try {
            Gson gson = new Gson();
            DataContent data = gson.fromJson(resultado, DataContent.class);
            textViewCEP.setText("CEP: " + data.getCep());
            textViewRua.setText("Logradouro: " + data.getLogradouro());
            textViewBairro.setText("Bairro: " + data.getBairro());
            textViewCidade.setText("Localidade: " + data.getLocalidade());
            textViewEstado.setText("UF: " + data.getUf());
        }
        catch(Exception ex) {}
        Button btnVoltar = findViewById(R.id.btnVoltar);
        btnVoltar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

}
