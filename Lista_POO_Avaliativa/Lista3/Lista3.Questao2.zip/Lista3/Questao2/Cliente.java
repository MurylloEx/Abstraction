package Lista3.Questao2;

public class Cliente extends Pessoa {

	public Cliente(String nome, String cpf) {
		super(nome, cpf);
	}

}