package Lista5.Questao1;

public interface Trabalhador {

	float calcularSalario();
	
}
