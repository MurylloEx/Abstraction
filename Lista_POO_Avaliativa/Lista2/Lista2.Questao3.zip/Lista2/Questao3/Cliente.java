package Lista2.Questao3;

public class Cliente extends Pessoa {

	public Cliente(String nome, String cpf) {
		super(nome, cpf);
	}
	
}