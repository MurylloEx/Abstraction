package Lista4.Questao2;

public interface Manutencao {

	void Atualizar();
	
}
