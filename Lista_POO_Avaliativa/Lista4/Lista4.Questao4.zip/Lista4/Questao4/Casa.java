package Lista4.Questao4;

public class Casa extends Imovel {
	
	public Casa(String rua, int numero, String bairro, String cidade, String estado, String cep, float preco,
			boolean alugado, boolean mobiliado) {
		super(rua, numero, bairro, cidade, estado, cep, preco, alugado, mobiliado);
	}
	
}
