package Lista4.Questao3;

public interface Trabalhador {

	float calcularSalario();
	
}
