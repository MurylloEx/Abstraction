package Lista6.QuestaoBonus;

public interface Trabalhador {

	float calcularSalario();
	
}
